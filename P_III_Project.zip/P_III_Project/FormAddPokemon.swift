//
//  FormAddPokemon.swift
//  P_III_Project
//
//  Created by Lívia Lima on 11/01/2022.
//

import SwiftUI

class NumbersOnly: ObservableObject {
    @Published var value = "" {
        didSet {
            let filtered = value.filter { $0.isNumber }
            
            if value != filtered {
                value = filtered
            }
        }
    }
}


struct FormAddPokemon: View {
    
    var pk: [Pokemons] = PkmList.List
    
    @State var name: String = ""
    @ObservedObject var attack = NumbersOnly()
    @ObservedObject var baseDamage = NumbersOnly()
    @ObservedObject var defence = NumbersOnly()
    @State var type: String = ""
    @ObservedObject var health = NumbersOnly()
    @State var image: String = "noImg"
    @State private var showingImagePicker = false
    
    var body: some View {
        NavigationView {
            Form {
                TextField("Name", text: $name)
                TextField("Attack", text: $attack.value)
                    .keyboardType(.decimalPad)
                TextField("Base Demage", text: $baseDamage.value)
                    .keyboardType(.decimalPad)
                TextField("Defence", text: $defence.value)
                    .keyboardType(.decimalPad)
                TextField("Type", text: $type)
                TextField("Health", text: $health.value)
                    .keyboardType(.decimalPad)
                TextField("image", text: $image)
            }
            .navigationBarTitle("Add Pokemon")
            .toolbar{
              Button(action: {
                  
                
                  //  let newPokemon = Pokemons(name: name, attack:attack, baseDamage: baseDamage, defence: defence, type: type, health: health,image: image)
              // pk.append(newPokemon)
                   
                  
                }, label: {
                    Text("Save")
                }
            )}
        }
    }
}

struct FormAddPokemon_Previews: PreviewProvider {
    static var previews: some View {
        FormAddPokemon()
    }
}


extension String{
    
    func asFloat () -> Float{
        Float(self) ?? 0.0
    }
}
