//
//  ContentView.swift
//  P_III_Project
//
//  Created by Lívia Lima on 28/11/2021.
//

import SwiftUI

struct ContentView: View {
    
    init(){
        UITableView.appearance().backgroundColor = .white
    
        
      
       
        }
    
    var pk: [Pokemons] = PkmList.List
    

    

    var body: some View {
        NavigationView{
            ZStack {
                VStack {
                    List(pk, id: \.id){ item in
                        HStack{
                            VStack{
                                Image(item.image)
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 120, height:120)
                                    .scaledToFit()
                                    .padding(.leading, 30)
                                
                            }
                            VStack{
                                Text("Name: \(item.name)")
                                Text("Attack:\(Int(floor(item.baseDamage)))")
                                Text("Defence: \(Int(floor(item.defence)))")
                                Text("Type: \(item.type)")
                                Text("Health: \(Int(floor(item.health)))")
                            }
                            VStack{
                                
                            }
                        }
                        
                    }
                    
                    Spacer()
                    

                    VStack
                    {
                    Button(action: {
                    }) {
                        NavigationLink(destination: battle2()) {
                        Text("Battle")
                            .frame(width: 280, height: 50, alignment: .center)
                            .background(Color.white)
                            .font(.system(size: 20,weight: .bold, design:.default))
                            .cornerRadius(10)
                        
                        }
                    }
                        
                    }
                    Spacer()
                        Button(action: {
                        }) {
                            NavigationLink(destination: FormAddPokemon()) {
                            Text("Add Pokemon")
                                .frame(width: 280, height: 50, alignment: .center)
                                .background(Color.white)
                                .font(.system(size: 20,weight: .bold, design:.default))
                                .cornerRadius(10)
                            
                            }
                        }
                }

                    Spacer()
                   
                   // Text("Type: \(pikachu["Growl"])")
                    
                }
                .background(LinearGradient(gradient: Gradient(colors: [Color.pink, Color.white])/*@END_MENU_TOKEN@*/, startPoint: .top, endPoint: .bottom)).edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all)
                
                
            }
            .navigationBarTitle("Pokemons")
        }
}
            


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
