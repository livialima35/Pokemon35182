//
//  Details.swift
//  P_III_Project
//
//  Created by Lívia Lima on 11/12/2021.
//

import SwiftUI

struct Details: View {
    @State var pokemon:Character
    var body: some View {
       
        VStack{
            
            HStack{
                Group{
                    Image(pokemon.image)
                        .resizable()
                        .frame(width: 150.0, height:170)
                        .scaledToFit()
                        .padding(.leading, 30)
                    VStack(alignment: .leading){
                        Group{
                        Text(pokemon.name)
                        Text("Ataque: \(pokemon.attack)")
                        Text("Defesa: \(pokemon.defense)")
                            /*ProgressView(value: Float(pokemon.xp), total: 100.0)
                            {
                               Text("To Evolve:")
                                    .font(.footnote)
                           }
                                .progressViewStyle(.linear)
                                .frame(width: 100)
                            
                          
                        }*/
                        .padding(.bottom, 5)
                        
                    }
                }
                Spacer()
            }//HStack
            .frame(height: 200)
            Spacer()
        }
        .navigationTitle(self.pokemon.name)
          
    }
}

struct Details_Previews: PreviewProvider {
    static var previews: some View {
        Details(pokemon: Character(name: "Pikachu", attack: 33, baseDamage: 40, defense: 40, type: "Elec", health: 300, image: "pikachu_2"))
    }
}
}
