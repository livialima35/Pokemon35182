//
//  imageAux.swift
//  P_III_Project
//
//  Created by Lívia Lima on 11/12/2021.
//

import Foundation
import SwiftUI

extension UIImage{
    
    static var defImg:UIImage{
        UIImage(named: "pikachu.png")!
    }
}
