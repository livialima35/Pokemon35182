//
//  battle2.swift
//  P_III_Project
//
//  Created by Livia Lima on 03/02/2022.
//

import SwiftUI

struct battle2: View {
    
    var pk: [Pokemons] = PkmList.List
    var yourpk = "No one"
    var enemypk = "No one"
    
  
    var player2 = Character(name: "Charmander", attack: 44, baseDamage: 28, defense: 24, type: "fire", health: 240,image:"nada")
    
    

    
    var body: some View {
            //General Display
            HStack
            {
                List(pk, id: \.id){ row in
                    ZStack{
                        if(row.name  == yourpk){
                          //  var player1 = Character(name: row.name, attack: row.attack, baseDamage: row.baseDamage, defense: row.defense,type: row.type,health: Int(row.health),image:row.image)
                        }
                        
                    }
                
            }
                ZStack
                {
                    Text("")
                    Capsule().frame(width: 100, height: 20).foregroundColor(.black)
                    Capsule().frame(width: 100, height: 20).foregroundColor(.green)
                }
            }
            

            
            ZStack (alignment: .bottom)
            {
                Capsule().frame(width: 100, height: 20).foregroundColor(.black)
                Capsule().frame(width: 50, height: 20).foregroundColor(.green)
            }
            
            VStack
            {
                Button(action: {

                }) {
                    Text(pikachu.0)
                        .font(.system(size: 17))
                        .fontWeight(.bold)
                        .foregroundColor(.green)
                        .frame(minWidth: 0, maxWidth: .infinity)
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 25)
                                .fill(Color.white)
                                .shadow(color: .gray, radius: 2, x: 0, y: 2)
                    )
                    .padding()
                    
                    Button(action: {

                    }) {
                        Text(pikachu.0)
                            .font(.system(size: 17))
                            .fontWeight(.bold)
                            .foregroundColor(.green)
                            .frame(minWidth: 0, maxWidth: .infinity)
                            .padding()
                            .background(
                                RoundedRectangle(cornerRadius: 25)
                                    .fill(Color.white)
                                    .shadow(color: .gray, radius: 2, x: 0, y: 2)
                        )
                        .padding()
                }
                }
                    
                    
            }
        }
    }

    func damages(){
        
    }

func run(){
    exit(0)
}


struct battle2_Previews: PreviewProvider {
    static var previews: some View {
        battle2()
    }
}
