//
//  Selections.swift
//  P_III_Project
//
//  Created by Lívia Lima on 05/12/2021.
//

import Foundation

//List of attacks

let pikachu = ("Growl", 20, "Thunder Shock", 35)
let charmander = ("Growl", 20, "Ember", 40)


// let pikachuv2 = [move1:"Growl", attack1: 20, move2:"Thunder Shock", attack2: 35]


