//
//  Lines.swift
//  P_III_Project
//
//  Created by Lívia Lima on 11/12/2021.
//

import SwiftUI

struct Lines: View {
    @State var pokemon:Character
    var body: some View {
      
        HStack{
            Image(self.pokemon.image)
                .resizable()
            
            VStack{
                Text(self.pokemon.name)
                

            }
            
        }
    }
}

struct Lines_Previews: PreviewProvider {
    static var previews: some View {
        Lines(pokemon: Character(name: "Pikachu", attack: 33, baseDamage: 40, defense: 40, type: "Elec", health: 300, image: "pikachu_2"))
    }
}
