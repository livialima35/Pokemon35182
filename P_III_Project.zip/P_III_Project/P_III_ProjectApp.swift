//
//  P_III_ProjectApp.swift
//  P_III_Project
//
//  Created by Lívia Lima on 28/11/2021.
//

import SwiftUI

@main
struct P_III_ProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
