//
//  FightFlow.swift
//  P_III_Project
//
//  Created by Lívia Lima on 08/12/2021.
//

import Foundation

//1º Select attack
//2º Compute Damage
//3º Apply Damage
//4º Check health

