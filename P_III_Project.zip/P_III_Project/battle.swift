import SwiftUI


struct battle: View {


//General Information necessary

	var pk: [Pokemons] = PkmList.List

	var poke1 = pikachu;

	print (poke1[0])

	print(pikachu[Growl])
	print(pikachu["Growl"])
	print(pikachu[0])
	
	
	print(pikachuv2[move1])
	print(pikachuv2[attack1])
	
	Text("Type: \(pikachuv2.move1)")
	startingbattle()
	
	
	
	//General Display
	HStack
	{
		ZStack
		{
			Label("")
			Capsule().frame(width: 100, height: 20).foregroundColor(.grey)
			Capsule().frame(width: 100, height: 20).foregroundColor(.green)
		}
	}
	
	Image(item.image)
    .resizable()
    .aspectRatio(contentMode: .fit)
    .frame(width: 100, height:100)
    .scaledToFit()
    .padding(.leading, 30)
	.alignmentGuide(.right)
	
	Image(item.image)
    .resizable()
    .aspectRatio(contentMode: .fit)
    .frame(width: 100, height:100)
    .scaledToFit()
    .padding(.leading, 30)
	.alignmentGuide(.left)
	
	ZStack (alignment: .bottom)
	{
		Capsule().frame(width: 100, height: 20).foregroundColor(.black)
		Capsule().frame(width: 50, height: 20).foregroundColor(.green)
	}
	
	VStack
	{
		Button(action:{})
		Text("")
        .frame(width: 100, height: 50, alignment: .center)
        .background(Color.white)
        .font(.system(size: 20,weight: .bold, design:.default))
		.cornerRadius(10)
	}
	
	//Action Listenners 
	button1.addTarget(self, action: "buttonClicked:", for: .touchUpInside)
	
}


func enemyattack(){

let randomInt = Int.random(in: 1..<2)

}
/*
func buttonClicked(_ sender: AnyObject?) {
  if sender === button1 {
    theyHP = theyHP - pokemonattack1
	enemyattack()
  }
}

func startingbattle()
{
	let yourHP = 100
	let enemyHP = 100
	let yourpk = 
	let enemypk = 
}
*/

func battleInfo()
{
	
}